/**
 * Shared Currency & Financial Arithmetic (XAF)
 * All monetary amounts are integers in Central African CFA Franc (XAF).
 * TVA is ALWAYS 0% (exempt for clinical medical diagnostic tests).
 * nanoLabs 5% fee applies strictly to the patient's out-of-pocket portion.
 */

import { PLATFORM_FEE_PCT, applyPercentage } from './percentage';

/**
 * Rounds any floating calculation to strict integer XAF
 */
export function roundXAF(amount: number): number {
  if (typeof amount !== 'number' || !Number.isFinite(amount)) throw new Error('A finite XAF amount is required.');
  return Math.round(amount);
}

/**
 * Sums an array of objects having an amount property
 */
export function sumLines<T extends { amount: number }>(lines: T[]): number {
  if (!lines || lines.length === 0) return 0;
  return lines.reduce((acc, line) => acc + roundXAF(line.amount || 0), 0);
}

/**
 * Splits gross diagnostic total into Insurance covered portion and Patient out-of-pocket share.
 * Rounding rule: coveredAmount is rounded; patientShare = total - coveredAmount
 */
export function splitInsurance(
  total: number,
  insuranceCoveragePercent: number
): { coveredAmount: number; patientShare: number } {
  const roundedTotal = roundXAF(total);
  if (!insuranceCoveragePercent || insuranceCoveragePercent <= 0) {
    return { coveredAmount: 0, patientShare: roundedTotal };
  }
  const cappedPct = Math.min(100, Math.max(0, insuranceCoveragePercent));
  const coveredAmount = applyPercentage(roundedTotal, cappedPct);
  const patientShare = Math.max(0, roundedTotal - coveredAmount);
  return { coveredAmount, patientShare };
}

/**
 * Calculates the nanoLabs platform record management fee on the patient's portion only.
 * 0% fee on insurance portion.
 */
export function applyPlatformFee(patientAmount: number): number {
  return applyPercentage(roundXAF(patientAmount), PLATFORM_FEE_PCT);
}

/**
 * Formats an amount as an integer CFA Franc string e.g. "12,500 XAF"
 */
export function formatXAF(amount: number): string {
  return `${roundXAF(amount).toLocaleString('fr-FR')} XAF`;
}

export interface BillInput {
  testPrices: number[];
  homeCollectionFee?: number;
  addOnsAmount?: number;
  insuranceCoveragePercent?: number;
}

/** Insurance covers diagnostic tests; collection/add-ons remain patient expenses.
 * The platform fee is charged once, on the complete patient portion only. */
export function calculateBill(input: BillInput) {
  if (!input.testPrices.length) throw new Error('Select at least one priced test.');
  const amounts = [...input.testPrices, input.homeCollectionFee ?? 0, input.addOnsAmount ?? 0];
  if (amounts.some(n => !Number.isSafeInteger(n) || n < 0)) throw new Error('Prices must be non-negative integer XAF amounts.');
  const coverage = input.insuranceCoveragePercent ?? 0;
  if (!Number.isFinite(coverage) || coverage < 0 || coverage > 100) throw new Error('Insurance coverage must be between 0 and 100.');
  const testsAmount = input.testPrices.reduce((sum, n) => sum + n, 0);
  const homeCollectionFee = input.homeCollectionFee ?? 0;
  const addOnsAmount = input.addOnsAmount ?? 0;
  const grossTotal = testsAmount + homeCollectionFee + addOnsAmount;
  if (!Number.isSafeInteger(grossTotal)) throw new Error('Invoice total is too large.');
  const { coveredAmount: insuranceCoveredAmount } = splitInsurance(testsAmount, coverage);
  const patientShare = grossTotal - insuranceCoveredAmount;
  const platformFeeAmount = applyPlatformFee(patientShare);
  const totalPatientDue = patientShare + platformFeeAmount;
  if (!Number.isSafeInteger(totalPatientDue)) throw new Error('Invoice total is too large.');
  return { testsAmount, homeCollectionFee, addOnsAmount, grossTotal, insuranceCoveragePercent: coverage,
    insuranceCoveredAmount, patientShare, platformFeePercent: PLATFORM_FEE_PCT, platformFeeAmount, totalPatientDue };
}
